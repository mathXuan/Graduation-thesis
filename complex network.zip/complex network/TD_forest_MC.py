from matplotlib import pyplot as plt
import numpy as np
import net

def pro():
    number = np.random.uniform(0, 3)
    if number <= 1:
        number = 1
    elif number <= 2:
        number = 2
    elif number <= 3:
        number = 3
    return number

def x_y(net):
    x = []
    y = []
    for i in range(net.shape[0]):
        x.append(i)
    for i in range(net.shape[1]):
        y.append(i)
    X, Y = np.meshgrid(np.array(x), np.array(y))
    return X, Y

def th_D(net):
    z = []
    for i in range(net.shape[0]):
        z_ = []
        for j in range(net.shape[1]):
            if net[i][j] == -1:
                z_.append(0)
            else:
                z_.append(pro())
        z.append(z_)
    z = np.array(z)
    return z

def th_D_show(x, y, z):
    ax = plt.axes(projection='3d')
    ax.plot_surface(x, y, z)
    plt.show()

if __name__ == '__main__':
    path = 'D:/python/complex network/2010120120101231'
    nvdi = net.load(path)
    x, y = x_y(nvdi)
    z = th_D(nvdi)
    th_D_show(x, y, z)
