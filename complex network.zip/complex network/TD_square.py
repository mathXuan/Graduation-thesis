import matplotlib.pyplot as plt
import random
import rule

def TD_net():
    net = []
    point = []
    for x in range(10):
        net.append([])
        for y in range(10):
            net[x].append([])
            for z in range(10):
                if random.randint(0, 1) == 0:
                    net[x][y].append(0)
                else:
                    net[x][y].append(1)
    for i in range(5):
        x = random.randint(0, 9)
        y = random.randint(0, 9)
        z = random.randint(0, 9)
        while net[x][y][z] == 1 or [x, y, z] in point:
            x = random.randint(0, 9)
            y = random.randint(0, 9)
            z = random.randint(0, 9)
        point.append([x, y, z])
    return net, point

def TD_point_rule(net, point):
    sta = 0
    for [x, y, z] in point:
        if net[x][y][z] == 2:
            if x != 9:
                if net[x + 1][y][z] == 0 and [x + 1, y, z] not in point:
                    point.append([x + 1, y, z])
                    sta = 1
            if x != 0:
                if net[x - 1][y][z] == 0 and [x - 1, y, z] not in point:
                    point.append([x - 1, y, z])
                    sta = 1
            if y != 9:
                if net[x][y + 1][z] == 0 and [x, y + 1, z] not in point:
                    point.append([x, y + 1, z])
                    sta = 1
            if y != 0:
                if net[x][y - 1][z] == 0 and [x, y - 1, z] not in point:
                    point.append([x, y - 1, z])
                    sta = 1
            if z != 9:
                if net[x][y][z + 1] == 0 and [x, y, z + 1] not in point:
                    point.append([x, y, z + 1])
                    sta = 1
            if z != 0:
                if net[x][y][z - 1] == 0 and [x, y, z - 1] not in point:
                    point.append([x, y, z - 1])
                    sta = 1
        else:
            net[x][y][z] = rule.TD_rule(net[x][y][z])
            sta = 1
    return sta

def TD_draw(net):
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    for x in range(10):
        for y in range(10):
            for z in range(10):
                if net[x][y][z] == 0:
                    ax.scatter(x, y, z, c='r', marker='o')
                elif net[x][y][z] == 1:
                    ax.scatter(x, y, z, c='b', marker='^')
                else:
                    ax.scatter(x, y, z, c='g', marker='*')

    plt.show()

if __name__ == '__main__':
    net, point = TD_net()
    TD_draw(net)
    sta = TD_point_rule(net, point)
    while sta == 1:
        sta = TD_point_rule(net, point)
    TD_draw(net)