import TD_forest_MC
import net
import rule
import random

def th_net(net, point, z):
    for i in range(len(point)):
        print(z[point[i][0], point[i][1]])
        h = random.randint(1, z[point[i][0], point[i][1]])
        point[i].append(h)
    return point

if __name__ == '__main__':
    path = 'G:/data/code/python/complex network/2010120120101231'
    nvdi = net.load(path)
    z = TD_forest_MC.th_D(nvdi)
    net, point = net.net(nvdi, 8)
    point = th_net(net ,point, z)
