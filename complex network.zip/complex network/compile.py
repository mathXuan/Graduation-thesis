import net
import numpy as np

def txt_load(path):
    A = np.zeros((681, 841), dtype=float)  # 先创建一个 3x3的全零方阵A，并且数据的类型设置为float浮点型
    f = open(path)  # 打开数据文件文件
    lines = f.readlines()  # 把全部数据文件读到一个列表lines中
    A_row = 0  # 表示矩阵的行，从0行开始
    for line in lines:  # 把lines中的数据逐行读取出来
        list = line.strip('\n').split(' ')  # 处理逐行数据：strip表示把头尾的'\n'去掉，split表示以空格来分割行数据，然后把处理后的行数据返回到list列表中
        A[A_row : ] = list[0 : 841]  # 把处理后的数据放到方阵A中。list[0:3]表示列表的0,1,2列数据放到矩阵A中的A_row行
        A_row += 1  # 然后方阵A的下一行接着读
    return A

if __name__ == '__main__':
    path = 'G:/data/code/python/complex network/2019070120190930'
    net = net.load(path)
    comp = txt_load('net.txt')
    same_nu = 0
    all_nu = 0
    for i in range(681):
        for j in range(841):
            if net[i, j] != -1:
                all_nu += 1
                if net[i, j] == comp[i, j]:
                    same_nu += 1
    print('acc =' + str(same_nu/all_nu))